import { RefreshCw } from 'lucide-react'

interface HeaderProps {
  project: string
  release: string
  testType: 'automation' | 'load'
  setTestType: (type: 'automation' | 'load') => void
}

const PROJECT_NAMES: Record<string, string> = {
  'proj-1': 'E-Commerce Platform',
  'proj-2': 'Payment Gateway',
  'proj-3': 'User Dashboard',
  'proj-4': 'Mobile API',
}

const RELEASE_NAMES: Record<string, string> = {
  'v1.0.0': 'v1.0.0',
  'v1.1.0': 'v1.1.0',
  'v1.2.0-beta': 'v1.2.0-beta',
  'dev': 'Development',
  'v1.5.0': 'v1.5.0',
  'v1.6.0-rc': 'v1.6.0-rc',
  'v2.0.0': 'v2.0.0',
  'v2.1.0': 'v2.1.0',
  'v3.0.0': 'v3.0.0',
  'v3.1.0': 'v3.1.0',
}

export function Header({ project, release, testType, setTestType }: HeaderProps) {
  return (
    <header className="border-b border-border bg-card">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              {PROJECT_NAMES[project]} - {RELEASE_NAMES[release]}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">Test Reports & Analytics</p>
          </div>
          
          <button 
            className="p-2 hover:bg-muted rounded-md transition-colors"
            aria-label="Refresh"
          >
            <RefreshCw className="w-5 h-5 text-muted-foreground hover:text-foreground" />
          </button>
        </div>

        {/* Test Type Filter */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setTestType('automation')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              testType === 'automation'
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-secondary'
            }`}
          >
            Automation Tests
          </button>
          <button
            onClick={() => setTestType('load')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              testType === 'load'
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-secondary'
            }`}
          >
            Load Tests
          </button>
        </div>
      </div>
    </header>
  )
}
