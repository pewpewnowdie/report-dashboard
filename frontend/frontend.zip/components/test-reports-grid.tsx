'use client'

import { useState, useEffect } from 'react'
import { ChevronDown, AlertCircle, CheckCircle, XCircle } from 'lucide-react'
import { getReports } from '@/lib/api'

interface TestReport {
  id: string
  name: string
  status: 'passed' | 'warning' | 'failed'
  passRate?: number
  total?: number
  passed?: number
  failed?: number
  lastRun: string
  duration: string
}

interface LoadTestReport {
  id: string
  name: string
  status: 'passed' | 'warning' | 'failed'
  avgResponseTime: number
  maxResponseTime: number
  throughput: number
  errorRate: number
  duration: string
  lastRun: string
  concurrent: number
}

interface TestReportsGridProps {
  testType: 'automation' | 'load'
  selectedProject: string
  selectedRelease: string
  onReportSelect: (reportId: string, type: 'automation' | 'load') => void
  searchQuery: string
  setSearchQuery: (query: string) => void
}

const AUTOMATION_REPORTS: TestReport[] = [
  {
    id: 'auto-1',
    name: 'UI Component Tests',
    status: 'passed',
    passRate: 96,
    total: 156,
    passed: 150,
    failed: 6,
    lastRun: '2 hours ago',
    duration: '2m 34s',
  },
  {
    id: 'auto-2',
    name: 'API Integration Tests',
    status: 'passed',
    passRate: 100,
    total: 89,
    passed: 89,
    failed: 0,
    lastRun: '1 hour ago',
    duration: '1m 12s',
  },
  {
    id: 'auto-3',
    name: 'E2E Workflows',
    status: 'warning',
    passRate: 88,
    total: 42,
    passed: 37,
    failed: 5,
    lastRun: '30 mins ago',
    duration: '3m 45s',
  },
  {
    id: 'auto-4',
    name: 'Authentication Flow',
    status: 'passed',
    passRate: 98,
    total: 67,
    passed: 66,
    failed: 1,
    lastRun: '45 mins ago',
    duration: '1m 8s',
  },
  {
    id: 'auto-5',
    name: 'Payment Processing',
    status: 'failed',
    passRate: 75,
    total: 28,
    passed: 21,
    failed: 7,
    lastRun: '15 mins ago',
    duration: '2m 3s',
  },
  {
    id: 'auto-6',
    name: 'Database Operations',
    status: 'passed',
    passRate: 100,
    total: 112,
    passed: 112,
    failed: 0,
    lastRun: '3 hours ago',
    duration: '1m 56s',
  },
]

const LOAD_REPORTS: LoadTestReport[] = [
  {
    id: 'load-1',
    name: 'API Load Test - Peak Hours',
    status: 'passed',
    avgResponseTime: 245,
    maxResponseTime: 1200,
    throughput: 15320,
    errorRate: 0.02,
    duration: '30 minutes',
    lastRun: '4 hours ago',
    concurrent: 500,
  },
  {
    id: 'load-2',
    name: 'Web Application Stress Test',
    status: 'warning',
    avgResponseTime: 512,
    maxResponseTime: 3400,
    throughput: 8920,
    errorRate: 0.15,
    duration: '45 minutes',
    lastRun: '2 hours ago',
    concurrent: 1000,
  },
  {
    id: 'load-3',
    name: 'Database Connection Pool',
    status: 'passed',
    avgResponseTime: 145,
    maxResponseTime: 450,
    throughput: 22500,
    errorRate: 0,
    duration: '20 minutes',
    lastRun: '5 hours ago',
    concurrent: 250,
  },
  {
    id: 'load-4',
    name: 'Payment Gateway Resilience',
    status: 'failed',
    avgResponseTime: 1200,
    maxResponseTime: 5000,
    throughput: 2100,
    errorRate: 3.45,
    duration: '25 minutes',
    lastRun: '1 hour ago',
    concurrent: 200,
  },
]

function getStatusIcon(status: 'passed' | 'warning' | 'failed') {
  switch (status) {
    case 'passed':
      return <CheckCircle className="w-5 h-5 text-green-500" />
    case 'warning':
      return <AlertCircle className="w-5 h-5 text-yellow-500" />
    case 'failed':
      return <XCircle className="w-5 h-5 text-red-500" />
  }
}

function TestReportItem({ report, onSelect }: { report: TestReport; onSelect: (id: string) => void }) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="border border-border rounded-lg overflow-hidden cursor-pointer">
      <button
        onClick={() => {
          setIsOpen(!isOpen)
          if (!isOpen) {
            onSelect(report.id)
          }
        }}
        className="w-full flex items-center justify-between px-4 py-3 bg-card hover:bg-secondary transition-colors"
      >
        <div className="flex items-center gap-3">
          {getStatusIcon(report.status)}
          <div className="text-left">
            <p className="font-medium text-foreground">{report.name}</p>
            <p className="text-xs text-muted-foreground">Last run: {report.lastRun}</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="font-semibold text-foreground">{report.passRate}%</p>
            <p className="text-xs text-muted-foreground">{report.passed}/{report.total}</p>
          </div>
          <ChevronDown
            className={`w-5 h-5 text-muted-foreground transition-transform ${
              isOpen ? 'rotate-180' : ''
            }`}
          />
        </div>
      </button>

      {isOpen && (
        <div className="px-4 py-4 bg-secondary border-t border-border">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Total Tests</p>
              <p className="text-lg font-bold text-foreground">{report.total}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Duration</p>
              <p className="text-lg font-bold text-foreground">{report.duration}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Failed</p>
              <p className="text-lg font-bold text-red-500">{report.failed}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function LoadTestItem({ report, onSelect }: { report: LoadTestReport; onSelect: (id: string) => void }) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="border border-border rounded-lg overflow-hidden cursor-pointer">
      <button
        onClick={() => {
          setIsOpen(!isOpen)
          if (!isOpen) {
            onSelect(report.id)
          }
        }}
        className="w-full flex items-center justify-between px-4 py-3 bg-card hover:bg-secondary transition-colors"
      >
        <div className="flex items-center gap-3">
          {getStatusIcon(report.status)}
          <div className="text-left">
            <p className="font-medium text-foreground">{report.name}</p>
            <p className="text-xs text-muted-foreground">Last run: {report.lastRun}</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="font-semibold text-foreground">{report.avgResponseTime}ms</p>
            <p className="text-xs text-muted-foreground">Avg Response</p>
          </div>
          <ChevronDown
            className={`w-5 h-5 text-muted-foreground transition-transform ${
              isOpen ? 'rotate-180' : ''
            }`}
          />
        </div>
      </button>

      {isOpen && (
        <div className="px-4 py-4 bg-secondary border-t border-border">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Max Response Time</p>
              <p className="text-lg font-bold text-foreground">{report.maxResponseTime}ms</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Throughput</p>
              <p className="text-lg font-bold text-foreground">{report.throughput} req/s</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Error Rate</p>
              <p className={`text-lg font-bold ${report.errorRate > 1 ? 'text-red-500' : 'text-green-500'}`}>
                {report.errorRate.toFixed(2)}%
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Concurrent Users</p>
              <p className="text-lg font-bold text-foreground">{report.concurrent}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export function TestReportsGrid({ testType, selectedProject, selectedRelease, onReportSelect, searchQuery, setSearchQuery }: TestReportsGridProps) {
  const [reports, setReports] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchReports = async () => {
      setIsLoading(true)
      try {
        const data = await getReports(selectedProject, selectedRelease)
        
        let reportList = testType === 'automation' ? data.pytestReports || [] : data.jmeterReports || []
        
        // Filter by search query
        if (searchQuery.trim()) {
          const query = searchQuery.toLowerCase()
          reportList = reportList.filter((report: any) => report.run_name.toLowerCase().includes(query))
        }
        
        setReports(reportList)
      } catch (error) {
        console.error('Failed to fetch reports:', error)
        setReports([])
      } finally {
        setIsLoading(false)
      }
    }

    fetchReports()
  }, [selectedProject, selectedRelease, testType, searchQuery])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <p className="text-muted-foreground">Loading reports...</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Report Search */}
      <div className="flex items-center gap-2">
        <input
          type="text"
          placeholder="Search reports..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1 px-3 py-2 bg-card border border-border rounded-md text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary"
        />
      </div>

      {testType === 'automation' ? (
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-foreground mb-4">Automation Tests</h2>
          {reports.length > 0 ? (
            reports.map((report) => (
              <TestReportItem key={report.run_id} report={report} onSelect={(id) => onReportSelect(id, 'automation')} />
            ))
          ) : (
            <p className="text-muted-foreground">No automation tests available for this release.</p>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-foreground mb-4">Load Tests</h2>
          {reports.length > 0 ? (
            reports.map((report) => (
              <LoadTestItem key={report.run_id} report={report} onSelect={(id) => onReportSelect(id, 'load')} />
            ))
          ) : (
            <p className="text-muted-foreground">No load tests available for this release.</p>
          )}
        </div>
      )}
    </div>
  )
}
