const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8080'

interface ApiResponse<T> {
  data?: T
  error?: string
}

export async function apiCall<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`
  const headers = {
    'Content-Type': 'application/json',
    ...options?.headers,
  }

  // Add access token if available
  const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : null
  if (token) {
    headers.Authorization = `Bearer ${token}`
  }

  const response = await fetch(url, {
    ...options,
    headers,
  })

  if (!response.ok) {
    const error = await response.text()
    throw new Error(error || `API error: ${response.status}`)
  }

  return response.json()
}

export async function getProjects() {
  const response = await apiCall<any>('/projects')
  
  // Handle both direct array and wrapped response
  if (Array.isArray(response)) {
    return response
  }
  
  if (response.projects && Array.isArray(response.projects)) {
    return response.projects
  }
  
  if (response.data && Array.isArray(response.data)) {
    return response.data
  }
  
  console.log('[v0] Unexpected API response structure:', response)
  return []
}

export async function login(username: string, password: string) {
  const response = await fetch(`${API_BASE_URL}/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      username,
      password,
    }),
  })

  if (!response.ok) {
    throw new Error('Login failed')
  }

  const data = await response.json()
  return data
}

export async function getReports(projectKey: string, releaseKey: string) {
  return apiCall(`/projects/${projectKey}/releases/${releaseKey}`)
}

export async function generateReport(runId: string) {
  return apiCall(`/generate_report/${runId}`, {
    method: 'GET',
  })
}

export async function getJmeterRun(runId: string) {
  return apiCall(`/jmeter_runs/${runId}`)
}

export async function getPytestRun(runId: string) {
  return apiCall(`/pytest_runs/${runId}`)
}
