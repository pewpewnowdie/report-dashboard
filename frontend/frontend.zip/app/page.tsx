'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Sidebar } from '@/components/sidebar'
import { Header } from '@/components/header'
import { TestReportsGrid } from '@/components/test-reports-grid'
import { FullReportView } from '@/components/full-report-view'
import { getProjects } from '@/lib/api'

interface Project {
  key: string
  name: string
  releases: Array<{ key: string; name: string }>
}

export default function Page() {
  const router = useRouter()
  const [projects, setProjects] = useState<Project[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedProject, setSelectedProject] = useState<string | null>(null)
  const [selectedRelease, setSelectedRelease] = useState<string | null>(null)
  const [testType, setTestType] = useState<'automation' | 'load'>('automation')
  const [sidebarSearchQuery, setSidebarSearchQuery] = useState('')
  const [reportSearchQuery, setReportSearchQuery] = useState('')
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null)
  const [selectedReportType, setSelectedReportType] = useState<'automation' | 'load'>('automation')

  // Check auth and fetch projects
  useEffect(() => {
    const checkAuthAndFetchProjects = async () => {
      const token = localStorage.getItem('access_token')
      if (!token) {
        router.push('/login')
        return
      }

      try {
        const data = await getProjects()
        console.log('[v0] Projects fetched:', data)
        setProjects(data)
        
        // Set first project and release as default
        if (data.length > 0) {
          console.log('[v0] Setting first project:', data[0].key)
          setSelectedProject(data[0].key)
          if (data[0].releases.length > 0) {
            console.log('[v0] Setting first release:', data[0].releases[0].key)
            setSelectedRelease(data[0].releases[0].key)
          }
        } else {
          console.log('[v0] No projects received')
        }
      } catch (error) {
        console.error('[v0] Failed to fetch projects:', error)
        router.push('/login')
      } finally {
        setIsLoading(false)
      }
    }

    checkAuthAndFetchProjects()
  }, [router])

  const handleTestTypeChange = (newType: 'automation' | 'load') => {
    setTestType(newType)
    setSelectedReportId(null)
  }

  const handleReleaseChange = (newRelease: string) => {
    setSelectedRelease(newRelease)
    setSelectedReportId(null)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    )
  }

  if (!selectedProject || !selectedRelease) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <p className="text-muted-foreground">No projects available</p>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Sidebar */}
      <Sidebar 
        projects={projects}
        selectedProject={selectedProject}
        setSelectedProject={setSelectedProject}
        selectedRelease={selectedRelease}
        setSelectedRelease={handleReleaseChange}
        searchQuery={sidebarSearchQuery}
        setSearchQuery={setSidebarSearchQuery}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          project={selectedProject}
          release={selectedRelease}
          testType={testType}
          setTestType={handleTestTypeChange}
        />
        
        <main className="flex-1 overflow-auto p-6">
          {selectedReportId ? (
            <FullReportView 
              reportId={selectedReportId}
              testType={selectedReportType}
              onClose={() => setSelectedReportId(null)}
            />
          ) : (
            <TestReportsGrid 
              testType={testType}
              selectedProject={selectedProject}
              selectedRelease={selectedRelease}
              onReportSelect={(id, type) => {
                setSelectedReportId(id)
                setSelectedReportType(type)
              }}
              searchQuery={reportSearchQuery}
              setSearchQuery={setReportSearchQuery}
            />
          )}
        </main>
      </div>
    </div>
  )
}
